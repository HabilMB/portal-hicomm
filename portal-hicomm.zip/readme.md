# **Spesification**:

1. Codeigniter v3
2. Bootstrap 4
3. Jquery Datatables
4. Ion Auth Codeigniter
5. Sweetalert2
6. Summernote

# **Step Configuration**:

1. create database with name db_blog
2. import file in folder database to phpmyadmin
3. done


# **How to login as admin :** 

1. add to url with "/admin" (http://localhost/portal-news/admin)


2. Email | password : admin@admin.com | password


![alt text](https://github.com/tegarpratama/portal-news/blob/master/capture.png?raw=true)
